package com.hive_udf;

import org.apache.hadoop.hive.ql.exec.UDF;

public class Hive_UDF extends UDF{
  public int evaluate(int value) {
	  return(value - 50);
  }
}
