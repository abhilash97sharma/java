package com.hive_udf;
import org.apache.hadoop.hive.ql.exec.UDF;

public class Length_Count extends UDF {
  public int evaluate(String s1) {
	  return(s1.length());
  }
}
