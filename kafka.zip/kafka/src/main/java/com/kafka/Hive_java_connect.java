package com.kafka;
import java.sql.SQLException;
import java.sql.Connection;
//import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.DriverManager;

public class Hive_java_connect {

	   private static String driverName = "org.apache.hadoop.hive.jdbc.HiveDriver";
	   public static void main(String[] args) throws SQLException {
		  try { 
	      Class.forName(driverName);
	      Connection con = DriverManager.
	      getConnection("jdbc:hive://localhost:10000/usrdb", "", "");
	      Statement stmt = con.createStatement();
	    //  stmt.executeQuery("CREATE DATABASE userdb1");
	      System.out.println("Database userdb created successfully.");
	      con.close();
		  }
		  catch(Exception e1) {
			  System.out.println("Some error occured");
		  }
	   }
}

