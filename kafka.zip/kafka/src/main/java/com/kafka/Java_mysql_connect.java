package com.kafka;
import java.sql.*;

public class Java_mysql_connect {
  public static void main(String[]args) throws Exception{
	  try {
		  Class.forName("com.mysql.jdbc.Driver");
		  System.out.println("Driver registered successfully");
		  Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/abhi", "root","root");
		  System.out.println("Connection established successfully");
		    Statement smt = con.createStatement();
		    ResultSet rs = smt.executeQuery("select * from a1");
		   while(rs.next()) {
			  System.out.println(rs.getInt(1)+","+rs.getString(2)+","+rs.getInt(3));
		  }
		  con.close();
	  }
	  catch(Exception e1) {
		  System.out.println("Some error has occured");
	  }
  }
}
