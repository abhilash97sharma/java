package org.spark;

import java.util.Arrays;

import org.apache.spark.SparkConf;
import org.apache.spark.api.java.*;
import scala.Tuple2;

public class Word_Count {

	public static void main(String[] args) {
		SparkConf conf = new SparkConf().setAppName("wordcount").setMaster("local");
		JavaSparkContext context = new JavaSparkContext(conf);
		JavaRDD<String> rdd = context.textFile("/home/abhilash/Documents/files/file");
	    JavaRDD<String> rdd1 = rdd.flatMap(content -> Arrays.asList(content.split(" ")).iterator());
		JavaPairRDD<String,Integer> rdd2 = rdd1.mapToPair(word -> new Tuple2<String,Integer>(word,1)).reduceByKey((a,b)-> a+b);
		rdd2.saveAsTextFile("/home/abhilash/Documents/rddfile");
	//	rdd2.saveAsTextFile("hdfs://192.168.43.236:9000/user/abhilash/files/rddfile");  //storing in hdfs
		context.close();
	}
}
