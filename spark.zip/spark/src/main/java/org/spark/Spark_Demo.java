package org.spark;

import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.function.*;
import org.apache.spark.SparkConf;
import java.util.*;

public class Spark_Demo {

	public static void main(String[] args) {
		SparkConf conf = new SparkConf().setAppName("RDD_Program").setMaster("local");
		JavaSparkContext context = new JavaSparkContext(conf);
		List<Integer> lst = Arrays.asList(2, 3, 4, 7, 9);
		JavaRDD<Integer> rdd = context.parallelize(lst);
//		JavaRDD<Integer> rdd1 = rdd.map(new Spark_Demo());
		@SuppressWarnings("unchecked")
		JavaRDD<Integer> rdd2 = rdd.filter(new Function(){

			public Object call(Object v1) throws Exception {
				// TODO Auto-generated method stub
				Integer i1 = (Integer) v1;
				if (i1 % 2 == 0)
					return true;
				else
					return false;
			}
		});
		rdd2.saveAsTextFile("/home/abhilash/Documents/rddfile");
	}

/*	public Object call(Object v1) throws Exception {
		// TODO Auto-generated method stub
		Integer i = (Integer) v1;
		return i * 2;
	}*/
}
