package org.spark;

public class User_define {
   public static char first(String s1) {
	   return s1.charAt(0);
   }
   
   public static String second(String s2) {
	   String []s = s2.split("::");
	   return s[1];
   }
}
