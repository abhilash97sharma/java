package org.movielens;

public class User_Define_func {
   public static void main(String[]args) {
	   String s1 = "1::Toy Story (1995)::Animation|Children's|Comedy";
	   System.out.println(s1.contains("Comedy"));
   }
}
