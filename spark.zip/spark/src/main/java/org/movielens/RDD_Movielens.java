package org.movielens;

import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaSparkContext;
import scala.Tuple2;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaPairRDD;
import org.spark.User_define;

public class RDD_Movielens {
   public static void main(String[]args) {
	   SparkConf conf = new SparkConf().setAppName("Movie_lens").setMaster("local");
	   JavaSparkContext context = new JavaSparkContext(conf);
	   JavaRDD<String> rdd_mov = context.textFile("/home/abhilash/Documents/ml-1m/movies.dat");
	   JavaRDD<String> rdd_user = context.textFile("/home/abhilash/Documents/ml-1m/users.dat");
	   JavaRDD<String> rdd2 = rdd_mov.filter(line -> line.contains("Comedy"));
//	   JavaRDD<String> rdd3 = rdd2.map(f -> f.substring(0, 20));
//	   rdd3.saveAsTextFile("/home/abhilash/Documents/rddfile1");
	   JavaPairRDD<String,String> rdd_user1 = rdd_user.mapToPair(word -> new Tuple2<String,String>(User_define.second(word),word));
       
//	   JavaPairRDD<String,String>rdd_user2 = rdd_user1.reduceByKey((word,word1) -> word+word1);
//	   JavaPairRDD<String,Iterable<String>> rdd_user3 = rdd_user1.groupByKey();
//	   rdd_user4.saveAsTextFile("/home/abhilash/Documents/rddfile5");
	   System.out.println("Count of the comedy movies:"+rdd2.count());
	   context.close();
   }
}
