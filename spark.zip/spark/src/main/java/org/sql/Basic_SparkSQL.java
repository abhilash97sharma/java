package org.sql;

import org.apache.spark.sql.*;
import org.apache.spark.sql.functions;

public class Basic_SparkSQL {
  public static void main(String[]args) {
	  SparkSession spark = SparkSession.builder().master("local").appName("Spark-SQL").getOrCreate();
	  Dataset<Row> df=spark.read().csv("/home/abhilash/Documents/ml-1m/movies.dat");
	  Dataset<Row> df1 = df.withColumn("ID", functions.split(df.col("_c0"), "::").getItem(0));
	  Dataset<Row> df2 = df1.withColumn("Movie", functions.split(df.col("_c0"), "::").getItem(1));
	  Dataset<Row> df3 = df2.withColumn("Genres", functions.split(df.col("_c0"), "::").getItem(2)).drop("_c0");
//	  Dataset<Row> df2 = df.withColumns(Seq("ID","Mov1"), Seq(functions.split(df.col("_c0"),"::").getItem(0)));
//	  df3.show(false);
	  df3.groupBy("Genres").count().show(5,false);
  }
}
