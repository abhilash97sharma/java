package package1;

public class Demo_Class {
	private int id;
	private String name;
	private float sal;

	public Demo_Class(int id, String name) {
		this.id = id;
		this.name = name;
	}
	
	public Demo_Class(int id, float sal) {
		this.id = id;
		this.sal = sal;
	}

	public int getId() {
		return id;
	}

	public String getName() {
		return name;
	}

	public float getSal() {
		return sal;
	}

}
