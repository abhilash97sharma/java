package package1;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test {
   public static void main(String[]args) {
	   ApplicationContext context = new ClassPathXmlApplicationContext("resource/spring.xml");
	   Demo_Class obj1 = (Demo_Class)context.getBean("t1");
	   System.out.println(obj1.getId());
	   System.out.println(obj1.getSal());
   }
}
